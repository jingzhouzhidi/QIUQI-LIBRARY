Modding Utility: Blank Map Template: 5632�2048 (Vanilla Size)

This is a tool for modders interested in making a total overhaul of the map. The old province map is replaced by a new one with just 46 giant rectangular provinces. In addition, all terrain features have been removed.

This mod is technically playable, with one test country. This is just for testing that a new game can successfully start. There are still many errors using this with the vanilla game; only game-crashing references to non-existant states/strategic regions/provinces, etc. were removed.

Enjoy!