ProvGenV2.0 Beta by James Rogers
07/08/2018

==================================================Set up==================================================
-LandMap: Defines land/sea/lake provinces. Each colored with their respective color:
	-Land:#9644C0
	-Sea :#051412
	-Lake:#00FF00

-ProvDenseMap: Defines the size of each land province, with black being the smallest and white the largest.
 Sea provinces are based on coastal distance and not this map.

-TerrainMap: Defines terrain using the following colors:
	-Plains  :#FF8142
	-Forest  :#59C755
	-Hills   :#F8FF99
	-Jungle  :#7FBF00
	-Marsh   :#4C6023
	-Mountain:#7C877D
	-Desert  :#FF3F00
	-Ocean	 :#0000FF
        -Lakes	 :#00FFFF	
 Urban terrain is placed down as a single pixel. The closest province to each pixel will be set as urban.
	-Urban   :#9B00FF

-BoundaryMap: If you want to define your own state/country borders for the provinces to align to, then load
this file under the "Boundary Input" tab. When loaded, provinces will not cross black (#000000) lines. If a 
tiny area is trapped by black boundaries, said area will cross a boundary to join to a neighbouring province.

All input maps should be the same size. Examples are included.

=================================================Donations================================================
I'm never going to put this software behind a pay wall, but if you could spare a dollar to keep me developing
this (and eventually turn this into a random map generator) then I'd be extremely grateful :)

Donate: paypal.me/ProvGen

Thanks for using ProvGen!

===================================================Help===================================================
We have a discord server to discuss the program. If you are having any issues or want to offer suggestions then
join us: https://discord.gg/cn6WC9H











